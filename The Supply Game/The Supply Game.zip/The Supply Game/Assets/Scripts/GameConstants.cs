﻿using UnityEngine;

public class GameConstants
{
	// UI Support
	public const string TIMER_PREFIX = "Time: ";
}
